package com.ryggs.towapp.riderapp.Messages;

public enum Errors {
    ERROR_LOGIN_GOOGLE,
    NOT_SUPPORT,
    WITHOUT_LOCATION,
    SENT_FAILED
}
