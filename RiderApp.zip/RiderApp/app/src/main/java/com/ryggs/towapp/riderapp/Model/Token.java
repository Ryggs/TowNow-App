package com.ryggs.towapp.riderapp.Model;

public class Token {
    private String Token;

    public Token() {
    }

    public Token(String token) {
        Token = token;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }
}
