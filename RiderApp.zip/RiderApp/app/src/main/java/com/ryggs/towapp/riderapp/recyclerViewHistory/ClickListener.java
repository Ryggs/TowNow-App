package com.ryggs.towapp.riderapp.recyclerViewHistory;

import android.view.View;

public interface ClickListener {
    void onClick(View view, int index);
}
