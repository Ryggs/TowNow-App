package com.ryggs.towapp.riderapp.Messages;

public enum Messages {
    PERMISSION_DENIED,
    RATIONALE,
    REQUEST_SUCCESS
}
