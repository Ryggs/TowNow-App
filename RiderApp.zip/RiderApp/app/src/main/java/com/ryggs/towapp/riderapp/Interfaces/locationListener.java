package com.ryggs.towapp.riderapp.Interfaces;

import com.google.android.gms.location.LocationResult;

public interface locationListener {
    void locationResponse(LocationResult response);
}
